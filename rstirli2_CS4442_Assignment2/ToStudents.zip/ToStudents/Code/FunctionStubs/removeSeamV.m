function imOut = removeSeamV(im,seam)
