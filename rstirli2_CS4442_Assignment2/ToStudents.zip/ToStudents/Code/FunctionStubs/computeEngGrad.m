
function eng = computeEngGrad(im,F)
