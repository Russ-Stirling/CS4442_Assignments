

function outIm = applyFilter(im,F)
