function [totalCost,imOut] = intelligentResize(imInput,v,h,W,mask,maskWeight)
