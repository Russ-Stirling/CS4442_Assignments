
function eng = computeEng(im,F,W,maskWeight)
