function imOut = addSeamV(im,seam)

