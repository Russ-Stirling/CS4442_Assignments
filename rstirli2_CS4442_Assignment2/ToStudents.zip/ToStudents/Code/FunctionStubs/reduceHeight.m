

function [seam,im,c] = reduceHeight(im,E)

