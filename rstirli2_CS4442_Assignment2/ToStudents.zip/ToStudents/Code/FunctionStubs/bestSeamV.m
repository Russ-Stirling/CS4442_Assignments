function [seam,c] = bestSeamV(M,P)

