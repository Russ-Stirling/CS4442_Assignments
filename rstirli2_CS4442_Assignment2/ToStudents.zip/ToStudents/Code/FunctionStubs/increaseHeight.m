% reduces height of the image by one pixel using seam carving

function [seam,im,c] = increaseHeight(im,E)
