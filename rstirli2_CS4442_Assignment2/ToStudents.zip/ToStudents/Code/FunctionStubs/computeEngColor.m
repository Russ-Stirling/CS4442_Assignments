
function eng = computeEngColor(im,W)
