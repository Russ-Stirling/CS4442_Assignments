

function [segm,e2]  = segmentGC(im,scribbleMask,lambda,numClusters,inftyCost)

