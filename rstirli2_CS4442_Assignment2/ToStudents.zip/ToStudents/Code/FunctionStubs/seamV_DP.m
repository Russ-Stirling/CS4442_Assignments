
function [M,P] = seamV_DP(E)
