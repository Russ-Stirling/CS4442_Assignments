
function [seam,im,c] = reduceWidth(im,E)

