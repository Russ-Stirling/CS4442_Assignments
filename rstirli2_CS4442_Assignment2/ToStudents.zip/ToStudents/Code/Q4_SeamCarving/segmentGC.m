
function segm  = segmentGC(im,scribbleMask)
